# README



These scripts have been borrowed/copied from https://github.com/pytorch/vision/tree/main/references/detection.